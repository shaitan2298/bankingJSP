package com.cg.banking.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet(urlPatterns = "/getAccountAllTransactions",loadOnStartup=1)
public class GetAccountAllTransactions extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BankingServices services;

	@Override
	public void init() throws ServletException {
		services=new BankingServicesImpl();

	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int accountNo = Integer.parseInt(request.getParameter("accountNo"));
		try {
			List<Transaction> transactions = services.getAccountAllTransaction(accountNo);
			request.setAttribute("transactions", transactions);
			request.getRequestDispatcher("getAccountAllTransactionList.jsp").forward(request, response);
		} catch (AccountNotFoundException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("getAccountAllTransaction.jsp").forward(request, response);
		} catch (BankingServiceDownException e) {
			
		}
	}

}
